﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ground : MonoBehaviour
{

    private MeshRenderer mesh;
    private Material m;
    private bool hasTower = false;
    private GameObject thisTower;
    private GameObject thisDetector;
    private Grid grid;

    // Use this for initialization
    void Start()
    {
        mesh = GetComponent<MeshRenderer>();
        grid = GameObject.Find("A*").GetComponent<Grid>();
        Debug.Log(grid);
        m = mesh.material;
        if (name.Substring(0, 3).Equals("Red"))
            m.color = new Color(0.9F, 0, 0);
        else
            m.color = new Color(0.2F, 0.2F, 0);
    }

    // Update is called once per frame
    void Update()
    {
    }

    public bool GetHasTower()
    {
        return hasTower;
    }

    public void SetHasTower()
    {
        hasTower = !hasTower;
    }

    void OnMouseUp()
    {
        if (game.theGame.CanUpdate() && !name.Equals("Red11") && !name.Equals("Red55"))
            Select();
    }

    void Select()
    {
        game.theGame.DisableEverything();
        if (hasTower)
        {
            game.U.Visible(this);
        }
        else
        {
            game.B.Visible(this);
        }
    }

    public void BuildTower(int i)
    {
        if (i == 0)
        {
            thisTower = (GameObject)Instantiate(Resources.Load("prefabs/Tower"), transform.position, new Quaternion(0, 180, 0, 0));
            game.m.MoreMoney(-50);
        }
        else if (i == 1)
        {
            thisTower = (GameObject)Instantiate(Resources.Load("prefabs/FreezeTower"), transform.position, new Quaternion(0, 180, 0, 0));
            game.m.MoreMoney(-60);
        }
        else
        {
            thisTower = (GameObject)Instantiate(Resources.Load("prefabs/ShockTower"), transform.position, new Quaternion(0, 180, 0, 0));
            game.m.MoreMoney(-70);
        }
        thisDetector = (GameObject)Instantiate(Resources.Load("prefabs/AvoidingCube"), transform.position, new Quaternion(0, 180, 0, 0));
        grid.SendMessage("CreateGrid");
        Unit[] activeUnits = GameObject.FindObjectsOfType<Unit>();
        foreach (Unit u in activeUnits)
        {
            u.SendMessage("FindPath");
        }
    }

    public void SellTower()
    {
        Destroy(thisTower.gameObject);
        Destroy(thisDetector.gameObject);
        game.m.MoreMoney(45);
        
    }

    public void UpgradeTower()
    {
        Destroy(thisTower.gameObject);
        game.m.MoreMoney(-50);
    }
}