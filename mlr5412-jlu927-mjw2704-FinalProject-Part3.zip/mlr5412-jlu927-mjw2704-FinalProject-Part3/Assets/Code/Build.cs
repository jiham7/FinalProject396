﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Build : MonoBehaviour
{
    private Button resumeButton;
    private Button buildButton;
    private Button shockButton;
    private Button freezeButton;
    ground currentGround;
    private bool enoughMoneyN = true;
    private bool enoughMoneyF = true;
    private bool enoughMoneyS = true;
    // Use this for initialization
    void Start()
    {
        game.B = GameObject.FindWithTag("Build").GetComponent<Build>();
        InitializeButtons();
        gameObject.SetActive(false);       
    }

    // Update is called once per frame
    void Update()
    {
        if (game.m.MoneyAmount() >= 50)
        {
            enoughMoneyN = true;
            buildButton.interactable = true;
        }
        else
        {
            enoughMoneyN = false;
            buildButton.interactable = false;
        }
        if (game.m.MoneyAmount() >= 60)
        {
            enoughMoneyF = true;
            freezeButton.interactable = true;
        }
        else
        {
            enoughMoneyF = false;
            freezeButton.interactable = false;
        }
        if (game.m.MoneyAmount() >= 70)
        {
            enoughMoneyS = true;
            shockButton.interactable = true;
        }
        else
        {
            enoughMoneyS = false;
            shockButton.interactable = false;
        }
    }

    public void Visible(ground g)
    {
        gameObject.SetActive(true);
        currentGround = g;
    }

    void InitializeButtons()
    {
        resumeButton = GameObject.Find("ResumeB").gameObject.GetComponent<Button>();
        resumeButton.onClick.AddListener(Resume);
        buildButton = GameObject.Find("Buy").gameObject.GetComponent<Button>();
        buildButton.onClick.AddListener(Buy);
        freezeButton = GameObject.Find("BuyFreeze").gameObject.GetComponent<Button>();
        freezeButton.onClick.AddListener(BuyFreeze);
        shockButton = GameObject.Find("BuyShock").gameObject.GetComponent<Button>();
        shockButton.onClick.AddListener(BuyShock);
    }

    void Resume()
    {
        gameObject.SetActive(false);
        game.theGame.EnableEverything();
    }

    void Buy()
    {
        if (CanBuildHere(currentGround))
        {
            currentGround.BuildTower(0);
            currentGround.SetHasTower();
            gameObject.SetActive(false);
            game.theGame.EnableEverything();
        }
    }

    void BuyFreeze()
    {
        if (CanBuildHere(currentGround))
        {
            currentGround.BuildTower(1);
            currentGround.SetHasTower();
            gameObject.SetActive(false);
            game.theGame.EnableEverything();
        }
    }

    void BuyShock()
    {
        if (CanBuildHere(currentGround))
        {
            currentGround.BuildTower(2);
            currentGround.SetHasTower();
            gameObject.SetActive(false);
            game.theGame.EnableEverything();
        }
    }


    bool CanBuildHere(ground g)
    {
        return true;
    }
}
