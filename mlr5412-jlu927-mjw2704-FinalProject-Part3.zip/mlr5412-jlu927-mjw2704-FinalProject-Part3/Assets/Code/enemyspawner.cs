﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

public class enemyspawner : MonoBehaviour
{

    private GameObject normalEnemy;
    private GameObject strongEnemy;
    private GameObject fastEnemy;
    private float spawntime;
    private bool wave_active;
    private float wave_wait_time;
    private float wave_ended_time;
    private List<char> current_wave;
    private StreamReader all_waves;
    private bool done;

    // Use this for initialization
    void Start()
    {
        //still need to load the two new enemy prefabs
        all_waves = new StreamReader("Assets/Resources/waves.txt");
        normalEnemy = (GameObject)Resources.Load("prefabs/Enemy", typeof(GameObject));
        fastEnemy = (GameObject)Resources.Load("prefabs/FastEnemy", typeof(GameObject));
        strongEnemy = (GameObject)Resources.Load("prefabs/StrongEnemy", typeof(GameObject));
        wave_ended_time = Time.time;
        spawntime = 1f;

        wave_wait_time = 300f*Time.deltaTime;
        StartCoroutine("PlayGame");
        StartCoroutine("SpawnNextUnit");
    }

    // Update is called once per frame
    void Update()
    {
        if (game.theGame.CanUpdate())
        {
            if (GameObject.FindGameObjectsWithTag("Enemy").Length == 0 && current_wave != null && current_wave.Count == 0 && !GameObject.Find("Panel").GetComponent<waveInfo>().isTimerFinished())
            {
                wave_active = false;
                wave_ended_time = Time.time;
            }
            //else if (Time.time > wave_ended_time + wave_wait_time)
            //{
            //    wave_active = true;
            //    Debug.Log("Here2");
            //}
            else if (GameObject.Find("Panel").GetComponent<waveInfo>().isTimerFinished())
            {
                wave_active = true;
            }

        }
    }

    private IEnumerator PlayGame()
    {
        while (true)
        {
            if (!wave_active && (current_wave == null || current_wave.Count == 0))
            {
                string s = all_waves.ReadLine();

                int normalCount = s.Split('n').Length - 1;
                int fastCount = s.Split('f').Length - 1;
                int strongCount = s.Split('s').Length - 1;

                GameObject.Find("Panel").GetComponent<waveInfo>().setNormalEnemyNumber(normalCount);
                GameObject.Find("Panel").GetComponent<waveInfo>().setFastEnemyNumber(fastCount);
                GameObject.Find("Panel").GetComponent<waveInfo>().setStrongEnemyNumber(strongCount);

                if (s != null)
                {
                    current_wave = s.ToList();
                }
                else
                {
                    Debug.Log("WE HAVE NO LINES LEFT??????");
                }
            }
            yield return true;
        }
    }

    private IEnumerator SpawnNextUnit()
    {
        while (true)
        {
            yield return new WaitForSeconds(spawntime);
            if (current_wave != null && current_wave.Count > 0 && GameObject.Find("Panel").GetComponent<waveInfo>().isTimerFinished())
            {
                char c = current_wave[0];
                current_wave.RemoveAt(0);
                if (c == 'n')
                {
                    Instantiate(normalEnemy, transform);
                }
                else if (c == 's')
                {
                    Instantiate(strongEnemy, transform);
                }
                else if (c == 'f')
                {
                    Instantiate(fastEnemy, transform);
                }
            }
        }
    }

    public bool isWaveActive()
    {
        return wave_active;
    }
    /*IEnumerator Waves()
    {
        while (Time.time < breaktime)
        {
            yield return null;
        }

        for (int i=0; i<5; i++)
        {
            BuildNormal();
            while (Time.time - lasttimespawned < spawntime)
            {
                yield return null;
            }       
        }

        /*while (Time.time - lasttimespawned < breaktime)
        {
            yield return null;
        }
        
        for (int i=0; i<10; i++)
        {
            BuildNormal();
            while (Time.time - lasttimespawned < spawntime)
            {
                yield return null;
            }        
        }*/

    /*yield return null;
}

void BuildNormal()
{
    Instantiate(normalEnemy, transform);
    spawntime = 3f;
    lasttimespawned = Time.time;
    /*spawntime = spawntime / 1.1f;
    if (spawntime < .8f)
    {
        spawntime = .8f;
    }*/
    /*}

    void BuildFast()
    {
        Instantiate(fastEnemy, transform);
        spawntime = 1f;
        lasttimespawned = Time.time;
        /*spawntime = spawntime / 1.1f;
        if (spawntime < .8f)
        {
            spawntime = .8f;
        }
    }*/

    /*void BuildStrong()
    {
        Instantiate(strongEnemy, transform);
        spawntime = 7f;
        lasttimespawned = Time.time;
        /*spawntime = spawntime / 1.1f;
        if (spawntime < .8f)
        {
            spawntime = .8f;
        }*/
    /*}*/

}
