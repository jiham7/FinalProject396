﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class waveInfo : MonoBehaviour
{

    private Text waveNumber;
    public Slider breakTimer;
    private Image waveStatusIcon;
    private Text waveStatusText;

    private Text normalEnemyNumber;
    private Text fastEnemyNumber;
    private Text strongEnemyNumber;


    private bool nowWave;

    // Use this for initialization
    void Start()
    {
        waveNumber = GameObject.Find("WaveNumber").GetComponent<Text>();
        breakTimer = GameObject.Find("BreakTimer").GetComponent<Slider>();
        waveStatusIcon = GameObject.Find("WaveStatusIcon").GetComponent<Image>();
        waveStatusText = GameObject.Find("WaveStatusText").GetComponent<Text>();

        normalEnemyNumber = GameObject.Find("NormalEnemyNumber").GetComponent<Text>();
        fastEnemyNumber = GameObject.Find("FastEnemyNumber").GetComponent<Text>();
        strongEnemyNumber = GameObject.Find("StrongEnemyNumber").GetComponent<Text>();

        nowWave = false;

        setFastEnemyNumber(1);
    }

    public void breakToWave()
    {
        //change waveBreakIcon from red to green
        waveStatusIcon.color = Color.green;
        //change waveStatusText from Break to Go
        waveStatusText.text = "Go";
        //change nowWave to true
        nowWave = true;
    }

    public void waveToBreak()
    {
        waveStatusIcon.color = Color.red;
        waveStatusText.text = "Break";
        nowWave = false;
        increaseWaveNumber();
        breakTimer.value = 0;
        breakTimer.gameObject.SetActive(true);
    }

    public void increaseWaveNumber()
    {
        int num = int.Parse(waveNumber.text);
        if (num < 9)
            num++;
        waveNumber.text = num.ToString();
    }

    public void setNormalEnemyNumber(int n)
    {
        int num = int.Parse(normalEnemyNumber.text);
        num = n;
        normalEnemyNumber.text = num.ToString();
    }

    public void setFastEnemyNumber(int n)
    {
        int num = int.Parse(fastEnemyNumber.text);
        num = n;
        fastEnemyNumber.text = num.ToString();
    }

    public void setStrongEnemyNumber(int n)
    {
        int num = int.Parse(strongEnemyNumber.text);
        num = n;
        strongEnemyNumber.text = num.ToString();
    }

    public void normalEnemyCountDecreaseByOne()
    {
        int num = int.Parse(normalEnemyNumber.text) -1;
        normalEnemyNumber.text = num.ToString();
    }

    public void fastEnemyCountDecreaseByOne()
    {
        int num = int.Parse(fastEnemyNumber.text) - 1;
        fastEnemyNumber.text = num.ToString();
    }

    public void strongEnemyCountDecreaseByOne()
    {
        int num = int.Parse(strongEnemyNumber.text) - 1;
        strongEnemyNumber.text = num.ToString();
    }

    public bool isTimerFinished()
    {
        if(breakTimer.value >= 100)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    // Update is called once per frame
    void Update()
    {
        //hide breakTimer and set bar value to 100 during wave
        if (nowWave == true)
        {
            breakTimer.gameObject.SetActive(false);
        }
        //during break, timer slider goes from 0 to 100, when 100, wave starts
        if (nowWave == false)
        {
            breakTimer.gameObject.SetActive(true);
            breakTimer.value += 8 * Time.deltaTime;
            if (isTimerFinished())
            {
                breakToWave();
            }
        }

        //go to break when all enemies are cleared
        if (int.Parse(normalEnemyNumber.text) <= 0 && int.Parse(fastEnemyNumber.text) <= 0 && int.Parse(strongEnemyNumber.text) <= 0)
        {
            waveToBreak();
            nowWave = false;
            breakTimer.gameObject.SetActive(true);
        }

        //if (GameObject.Find("EnemySpawner").GetComponent<enemyspawner>().isWaveActive())
        //{
        //    nowWave = GameObject.Find("EnemySpawner").GetComponent<enemyspawner>().isWaveActive();
        //}

    }
}
