﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour
{
    private int health;
    private float speed;
    private float basespeed;
    private float slow_amount;
    private float last_tick;
    private float update_rate;
    private int slow_tower_damage_taken;
    private float max_chain_distance_squared;
    private int slow_distance = 3;
    private MeshRenderer mesh;
    private Material m;
    private GameObject spark;

    // Use this for initialization
    void Start()
    {
        mesh = GetComponent<MeshRenderer>();
        m = mesh.material;
        if (gameObject.tag.Equals("Enemy"))
        {
            health = 10;
            basespeed = 1f;
            m.color = new Color(0.4F, 0.4F, 0.4F);
        }
        else if (gameObject.tag.Equals("FastEnemy"))
        {
            health = 4;
            basespeed = 3f;
            m.color = new Color(0.1F, 0.1F, 0.1F);
        }
        else if (gameObject.tag.Equals("StrongEnemy"))
        {
            health = 20;
            basespeed = 0.5f;
            m.color = new Color(0.7F, 0.7F, 0.7F);
        }
        max_chain_distance_squared = 5;
        slow_tower_damage_taken = 1;
        update_rate = 1f;
        last_tick = Time.time;
        slow_amount = .4f;
        spark = (GameObject)Resources.Load("prefabs/Spark", typeof(GameObject));
        //need more spesific setups, but this is just the base unit
    }

    // Update is called once per frame
    void Update()
    {
        //applies needed slows and damage from slow towers (occassionally updates)
        if ((Time.time - last_tick) > update_rate)
        {
            GameObject[]
                freezetowers =
                    GameObject.FindGameObjectsWithTag(
                        "Freezer"); //Freezer tag should be applied to a non Cannon part of a tower object
            speed = basespeed;
            foreach (GameObject f in freezetowers)
            {
                if ((transform.position - f.transform.position).magnitude < slow_distance)
                {
                    //applies slow
                    speed = speed * (1 - slow_amount);
                    //applies damage
                    GotHit(slow_tower_damage_taken);
                }
            }
        }

        //pathfinding
        //NEED TO ADD IN THE FACT THAT DIFFERENT THINGS HAVE DIFFERENT SPEED INTO THIS
        //this value to multiply by is "speed"
        if (game.theGame.CanUpdate())
            Pathfinding();
        else
        {
            gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
    }

    void GotHit(int value)
    {
        health = health - value;
        CheckDeath();
    }

    //function called by lightning tower that chains to nearby enemies, should be initially passed damage value and an empty array upon the tower firing
    public void GotChained(int value, List<enemy> alreadyhit)
    {
        GotHit(1000);
        //is only allowed to hit up to 3 enemies in one hit
        if (alreadyhit.Count > 2)
        {
            return;
        }
        alreadyhit.Add(this);//don't want to hit myself
        //so we are going to find all the ally's of the enemy...
        GameObject[] allys = GameObject.FindGameObjectsWithTag("Enemy");
        if (allys.Length != 0)
        {
            bool skip;
            //find the closest enemy that this bounce hasn't hit yet
            enemy closest = allys[0].transform.GetComponent<enemy>();
            float sqrclose = 150;//bug fixed :D
            foreach (GameObject a in allys)
            {
                skip = false;
                //make sure it hasn't been hit yet
                foreach (enemy e in alreadyhit)
                {
                    if (a.transform.GetComponent<enemy>() == e)
                    {
                        skip = true;
                        break;
                    }
                }
                //it hasnt been hit: see if it is closer then the current closest
                if (!skip)
                {
                    float newdist = (a.transform.position - transform.position).sqrMagnitude;
                    if (sqrclose > newdist)
                    {
                        closest = a.transform.GetComponent<enemy>();
                        sqrclose = newdist;
                    }
                }
            }
            //fire at the closest enemy if it is not out of range
            if (sqrclose < max_chain_distance_squared)
            {
                closest.GotChained(value, alreadyhit);
                Spark(closest.transform.position);
            }
        }
    }

    void CheckDeath()
    {
        if (health < 0)
        {
            Destroy(gameObject);
            game.theGame.EnemyKilled();
            game.m.MoreMoney(10);
            if (gameObject.tag == "Enemy")
            {
                GameObject.Find("Panel").GetComponent<waveInfo>().normalEnemyCountDecreaseByOne();
            }
            if (gameObject.tag == "FastEnemy")
            {
                GameObject.Find("Panel").GetComponent<waveInfo>().fastEnemyCountDecreaseByOne();
            }
            if (gameObject.tag == "StrongEnemy")
            {
                GameObject.Find("Panel").GetComponent<waveInfo>().strongEnemyCountDecreaseByOne();
            }
        }
    }

    //sets the current velocity to the fastest path to the base
    void Pathfinding()
    {
        ////very basic implmentation
        //GameObject target = FindObjectOfType<playerbase>().gameObject;
        //Transform targetposn = target.transform;
        //Rigidbody r = gameObject.GetComponent<Rigidbody>();
        //r.velocity = (targetposn.position - transform.position).normalized * 1;
    }

    void Spark(Vector3 end)
    {
        Vector3 start = transform.position;
        float amount = (start - end).sqrMagnitude;
        for (int i = 0; i <= amount; i++)
            Object.Instantiate(spark, Vector3.Lerp(start, end, i / amount), new Quaternion(0, 0, 0, 0));
    }

    void OnCollisionEnter(Collision c)
    {
        if (c.gameObject.name == "Base") //we are colliding with the base
        {
            c.gameObject.SendMessage("GotHit", 5);
            game.theGame.EnemyKilled();
            Destroy(gameObject);
            if (gameObject.tag == "Enemy")
            {
                GameObject.Find("Panel").GetComponent<waveInfo>().normalEnemyCountDecreaseByOne();
            }
            if (gameObject.tag == "FastEnemy")
            {
                GameObject.Find("Panel").GetComponent<waveInfo>().fastEnemyCountDecreaseByOne();
            }
            if (gameObject.tag == "StrongEnemy")
            {
                GameObject.Find("Panel").GetComponent<waveInfo>().strongEnemyCountDecreaseByOne();
            }
        }
    }
}